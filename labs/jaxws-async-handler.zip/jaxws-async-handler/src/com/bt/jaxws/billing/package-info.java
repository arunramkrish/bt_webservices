@javax.xml.bind.annotation.XmlSchema(namespace = "http://billing.jaxws.bt.com/")
package com.bt.jaxws.billing;
