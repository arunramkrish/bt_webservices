package orders.controller;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class OrderControllerTest1 {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Test
	public void testGetOrder() {
		fail("Not yet implemented");
	}

}
