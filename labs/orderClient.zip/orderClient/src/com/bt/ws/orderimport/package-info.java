@javax.xml.bind.annotation.XmlSchema(namespace = "http://order.ws.bt.com/")
package com.bt.ws.orderimport;
