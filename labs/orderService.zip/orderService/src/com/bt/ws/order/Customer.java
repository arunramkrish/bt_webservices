package com.bt.ws.order;

public class Customer {
	private String name;
}
