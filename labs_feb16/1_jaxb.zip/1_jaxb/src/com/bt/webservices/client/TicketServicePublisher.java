package com.bt.webservices.client;

import javax.xml.ws.Endpoint;

import com.bt.webservices.service.JaxwsTicketBookingService;

public class TicketServicePublisher {

	public static void main(String[] args) {
		Endpoint.publish("http://localhost:8999/ticketService", 
				new JaxwsTicketBookingService());

	}

}
