package com.bt.webservices.entity;

import javax.xml.bind.annotation.XmlSeeAlso;

@XmlSeeAlso(Ticket.class)
public abstract class BaseTicket {

}
