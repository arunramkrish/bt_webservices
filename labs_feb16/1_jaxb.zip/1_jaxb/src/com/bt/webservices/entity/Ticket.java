package com.bt.webservices.entity;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlType(namespace="com.bt.webservices.entity")
public class Ticket {
	private String id; 
	private Customer customer;
	private Date bookingDate;
	private Date journeyDate;
	private String source;
	private String destination;
	private Float cost;
	
	public Ticket() {
		super();
	}


	public Ticket(String id, Customer customer, Date bookingDate, Date journeyDate, String source, String destination,
			Float cost) {
		super();
		this.id = id;
		this.customer = customer;
		this.bookingDate = bookingDate;
		this.journeyDate = journeyDate;
		this.source = source;
		this.destination = destination;
		this.cost = cost;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public Date getBookingDate() {
		return bookingDate;
	}


	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}


	public Date getJourneyDate() {
		return journeyDate;
	}


	public void setJourneyDate(Date journeyDate) {
		this.journeyDate = journeyDate;
	}


	public String getSource() {
		return source;
	}


	public void setSource(String source) {
		this.source = source;
	}


	public String getDestination() {
		return destination;
	}


	public void setDestination(String destination) {
		this.destination = destination;
	}


	public Float getCost() {
		return cost;
	}


	public void setCost(Float cost) {
		this.cost = cost;
	}


	@Override
	public String toString() {
		return "Ticket [id=" + id + ", customer=" + customer + ", bookingDate=" + bookingDate + ", journeyDate="
				+ journeyDate + ", source=" + source + ", destination=" + destination + ", cost=" + cost + "]";
	}
	
	
}
