package com.bt.webservices.marshaller;

import java.io.File;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.bt.webservices.entity.BaseTicket;
import com.bt.webservices.entity.Customer;
import com.bt.webservices.entity.Gender;
import com.bt.webservices.entity.IdProofType;
import com.bt.webservices.entity.Ticket;

public class TicketMarshaller {

	public static void main(String[] args) {
		try {
			JAXBContext context = JAXBContext.newInstance(BaseTicket.class);
//			JAXBContext context = JAXBContext.newInstance("com.bt.webservices.entity");

			Marshaller marshaller = context.createMarshaller();

			Ticket ticket = createTicket();
			
			Customer customer = createCustomer();
			
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			marshaller.marshal(ticket, new File("ticket.xml"));

		} catch (JAXBException e) {
			e.printStackTrace();
		}

	}

	private static Ticket createTicket() {
		Ticket ticket = new Ticket("PXR678", createCustomer(), new Date(), new Date(), "Bangalore", "New Delhi", 5000F);

		return ticket;
	}

	private static Customer createCustomer() {
		Customer customer = new Customer(12345L, "BT", "Bangalore", "12345678", new Date(), Gender.MALE,
				IdProofType.PAN);
		return customer;
	}
}
