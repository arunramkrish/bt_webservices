package com.bt.webservices.marshaller;

import java.io.File;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.SchemaFactory;

import org.xml.sax.SAXException;

import com.bt.webservices.entity.Ticket;

public class TicketUnmarshaller {
	public static void main(String[] args) throws SAXException {
		try {
			// JAXBContext context = JAXBContext.newInstance(Ticket.class);
			JAXBContext context = JAXBContext.newInstance("com.bt.webservices.entity");

			Unmarshaller unmarshaller = context.createUnmarshaller();
			
//			unmarshaller.setValidating(true);
			unmarshaller.setSchema(SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI)
					.newSchema(new File("src/schema1.xsd")));
			Ticket ticket = (Ticket) unmarshaller.unmarshal(new File("ticket.xml"));

			System.out.println(ticket);

		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}

}
