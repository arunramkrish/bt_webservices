package com.bt.webservices.service;

import javax.xml.ws.WebFault;

@WebFault(faultBean="faultInfo",messageName="InvalidDateException")
public class InvalidDateException extends Exception {
	private InvalidDateExceptionBean faultInfo;
	
	public InvalidDateException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidDateException(String message) {
		super(message);
		faultInfo.setMessage(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidDateException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidDateException(String message, Throwable cause) {
		super(message, cause);
		faultInfo.setMessage(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidDateException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		faultInfo.setMessage(message);// TODO Auto-generated constructor stub
	}

	public InvalidDateExceptionBean getFaultInfo() {
		return faultInfo;
	}

	public void setFaultInfo(InvalidDateExceptionBean faultInfo) {
		this.faultInfo = faultInfo;
	}

	
}
