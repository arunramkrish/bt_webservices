package com.bt.webservices.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jws.HandlerChain;
import javax.jws.WebService;
import javax.xml.ws.Holder;

import com.bt.webservices.entity.Ticket;

@WebService(endpointInterface = "com.bt.webservices.service.TicketBookingService")
@HandlerChain(file = "JaxwsTicketBookingServiceService_handler.xml")
public class JaxwsTicketBookingService implements TicketBookingService {
	private static Map<String, Ticket> bookedTickets = new HashMap<>();

	@Override
	public String bookTicket(Ticket ticketToBook) {
		String ticketId = (bookedTickets.size() + 1) + "TKT";
		ticketToBook.setId(ticketId);

		bookedTickets.put(ticketId, ticketToBook);

		return ticketId;
	}

	@Override
	public Ticket getTicket(String id) {
		return bookedTickets.get(id);
	}

	@Override
	public Holder<List<Ticket>> getTickets(Date from, Date to) throws InvalidDateException {
		Holder<List<Ticket>> ticketsHolder = new Holder<>();
		ArrayList<Ticket> tickets = new ArrayList<>();
		
		if (from.compareTo(to) >= 0) {
			throw new InvalidDateException("From should be on or before to");
		}
		for (Ticket ticket : bookedTickets.values()) {
			if ((ticket.getJourneyDate().compareTo(from) >= 0) && (ticket.getJourneyDate().compareTo(to) <= 0)) {
				tickets.add(ticket);
			}

		}
		
		ticketsHolder.value = tickets;
		return ticketsHolder;
	}

}
