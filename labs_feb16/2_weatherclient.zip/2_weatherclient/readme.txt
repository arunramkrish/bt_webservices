Demonstrates JAX-WS client consuming weather report from publicly available web service.

Use following command to download the stub from wsdl from the project directory

wsimport -d src -keep http://www.webservicex.net/globalweather.asmx?wsdl
