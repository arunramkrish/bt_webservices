package net.webservicex.client;

import net.webservicex.GlobalWeather;
import net.webservicex.GlobalWeatherSoap;

public class GlobalWeatherClient {

	public static void main(String[] args) {
		GlobalWeather gw = new GlobalWeather();
		
		GlobalWeatherSoap service = gw.getPort(GlobalWeatherSoap.class);
		
		System.out.println(service.getCitiesByCountry("IN"));
		
		System.out.println(service.getWeather("Madras", "India"));
				

	}

}
