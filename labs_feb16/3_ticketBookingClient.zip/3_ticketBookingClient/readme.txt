JAX-WS client for the service generated in 1_jaxb projec

Run the Endpoint publisher class present in 1_jaxb as Java application

From the project root directory, execute the following command to generate client stub

wsimport -d src -keep http://localhost:8999/ticketService?wsdl

Run the junit test case to invoke the web service.

You can see all ways of invoking it.

You can run TCP/IP monitor in eclipse in a different port and then change the address property in request context to place web service request via TCP/IP monitor
