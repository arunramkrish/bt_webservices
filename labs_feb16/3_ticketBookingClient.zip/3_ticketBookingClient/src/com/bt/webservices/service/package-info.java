@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.webservices.bt.com/")
package com.bt.webservices.service;
