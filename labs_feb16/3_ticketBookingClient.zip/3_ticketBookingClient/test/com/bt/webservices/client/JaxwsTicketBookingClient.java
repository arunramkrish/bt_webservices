package com.bt.webservices.client;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.bt.webservices.service.Customer;
import com.bt.webservices.service.Gender;
import com.bt.webservices.service.IdProofType;
import com.bt.webservices.service.TicketBookingService;

import entity.webservices.bt.com.Ticket;

public class JaxwsTicketBookingClient {
	private static TicketBookingService service;

	private static URL wsdlDocumentLocation = null;
	private static QName serviceName = new QName("http://service.webservices.bt.com/",
			"JaxwsTicketBookingServiceService");

	static {
		try {
			wsdlDocumentLocation = new URL("http://localhost:8999/ticketService?wsdl");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		Service svc = Service.create(wsdlDocumentLocation, serviceName);
		service = svc.getPort(TicketBookingService.class);

		// service = (new
		// JaxwsTicketBookingServiceService().getJaxwsTicketBookingServicePort());

		((BindingProvider) service).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
				"http://localhost:9999/ticketService");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		String ticketId = service.bookTicket(createTicket());

		Ticket ticket = service.getTicket(ticketId);

		Assert.assertEquals("Bangalore", ticket.getSource());
	}

	private static Ticket createTicket() {
		Ticket ticket = new Ticket();
		ticket.setCustomer(createCustomer());
		ticket.setBookingDate(getCalendar(new Date()));
		ticket.setJourneyDate(getCalendar(new Date()));
		ticket.setSource("Bangalore");
		ticket.setDestination("New Delhi");
		ticket.setCost(5000F);

		return ticket;
	}

	private static XMLGregorianCalendar getCalendar(Date date) {
		try {

			GregorianCalendar cal = new GregorianCalendar();
			cal.setTime(date);
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch (DatatypeConfigurationException e) {
			e.printStackTrace();
		}
		return null;
	}

	private static Customer createCustomer() {
		Customer customer = new Customer();
		customer.setId(12345L);
		customer.setCustomerName("BT");
		customer.setAddress("Bangalore");
		customer.setPhoneNumber("12345678");
		customer.setDob(getCalendar(new Date()));
		customer.setGender(Gender.MALE);
		customer.setIdProof(IdProofType.PAN);

		return customer;
	}

}
