
package com.bt.webservices.service;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for idProofType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="idProofType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="PAN"/>
 *     &lt;enumeration value="VOTER_ID"/>
 *     &lt;enumeration value="DRIVING_LICENSE"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "idProofType")
@XmlEnum
public enum IdProofType {

    PAN,
    VOTER_ID,
    DRIVING_LICENSE;

    public String value() {
        return name();
    }

    public static IdProofType fromValue(String v) {
        return valueOf(v);
    }

}
