@javax.xml.bind.annotation.XmlSchema(namespace = "com.bt.webservices.entity")
package entity.webservices.bt.com;
