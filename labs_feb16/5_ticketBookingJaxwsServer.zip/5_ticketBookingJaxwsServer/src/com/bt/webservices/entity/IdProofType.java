package com.bt.webservices.entity;

public enum IdProofType {
	PAN, VOTER_ID, DRIVING_LICENSE;
}
