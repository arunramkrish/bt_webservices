Download JAX-RS Reference Implementation (Jersey) jars.
Place all downloaded jars in WEB-INF/lib
