package com.bt.webservices.adapter;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateParameter implements Serializable {
	private static final long serialVersionUID = -8104289238517510856L;

	private static SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	
	private Date date;
	
	public DateParameter(Date date) {
		this.date = date;
	}
	
	public static DateParameter valueOf(String dateString) {
		try {
			return new DateParameter(format.parse(dateString));
		} catch (ParseException e) {
			return new DateParameter(new Date());
		}
	}

	public static SimpleDateFormat getFormat() {
		return format;
	}

	public static void setFormat(SimpleDateFormat format) {
		DateParameter.format = format;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
}
