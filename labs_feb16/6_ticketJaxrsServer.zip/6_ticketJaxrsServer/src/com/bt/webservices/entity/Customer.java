package com.bt.webservices.entity;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorOrder;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.bt.webservices.adapter.DateAdapter;

@XmlRootElement
@XmlAccessorOrder(XmlAccessOrder.UNDEFINED)
@XmlAccessorType(XmlAccessType.FIELD)
public class Customer {
	@XmlAttribute
	private Long id;
	
	@XmlAttribute (name="customerName", required=true)
	private String name;
	private String address;
	private String phoneNumber;
	
	@XmlElement
	@XmlJavaTypeAdapter(DateAdapter.class)
	private Date dob;
	
	private Gender gender;
	private IdProofType idProof;
	
	public Customer(Long id, String name, String address, String phoneNumber, Date dob, Gender gender,
			IdProofType idProof) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.phoneNumber = phoneNumber;
		this.dob = dob;
		this.gender = gender;
		this.idProof = idProof;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
//	@XmlElement
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public IdProofType getIdProof() {
		return idProof;
	}
	public void setIdProof(IdProofType idProof) {
		this.idProof = idProof;
	}
	
}
