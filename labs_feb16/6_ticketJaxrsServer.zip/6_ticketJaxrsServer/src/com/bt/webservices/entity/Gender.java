package com.bt.webservices.entity;

public enum Gender {
	MALE, FEMALE;
}
