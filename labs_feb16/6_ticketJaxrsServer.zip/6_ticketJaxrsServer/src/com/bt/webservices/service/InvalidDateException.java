package com.bt.webservices.service;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

public class InvalidDateException extends WebApplicationException {
	public InvalidDateException() {
		super(Response.status(Status.NOT_FOUND).build());
	}

	/**
	 * Create a HTTP 404 (Not Found) exception.
	 * 
	 * @param message
	 *            the String that is the entity of the 404 response.
	 */
	public InvalidDateException(String message) {
		super(Response.status(Status.NOT_FOUND).entity(message).type("text/plain").build());
	}
}
