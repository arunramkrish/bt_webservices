package com.bt.webservices.service;

public class InvalidDateExceptionBean {
	private String message;
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public InvalidDateExceptionBean() {
		// TODO Auto-generated constructor stub
	}

}
