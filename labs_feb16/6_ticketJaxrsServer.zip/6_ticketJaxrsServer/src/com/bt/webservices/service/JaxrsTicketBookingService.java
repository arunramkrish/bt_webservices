package com.bt.webservices.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.bt.webservices.adapter.DateParameter;
import com.bt.webservices.entity.Customer;
import com.bt.webservices.entity.Gender;
import com.bt.webservices.entity.IdProofType;
import com.bt.webservices.entity.Ticket;

@Path("/tickets")
public class JaxrsTicketBookingService implements TicketBookingService {
	private static Map<String, Ticket> bookedTickets = new HashMap<>();

	@Override
	@POST
	@Consumes(MediaType.APPLICATION_XML)
	public String bookTicket(Ticket ticketToBook) {
		String ticketId = (bookedTickets.size() + 1) + "TKT";
		ticketToBook.setId(ticketId);

		bookedTickets.put(ticketId, ticketToBook);

		return ticketId;
	}

	@Override
	@Path("/{id}")
	@GET
	public Ticket getTicket(@PathParam("id") String id) {
		if (bookedTickets.size() == 0) {
			bookedTickets.put(id, createTicket());
		}
		return bookedTickets.get(id);
	}

	@Override
	@GET
	public List<Ticket> getTickets(@QueryParam("from") DateParameter fromParam,
			@QueryParam("to") DateParameter toParam) throws InvalidDateException {
		ArrayList<Ticket> tickets = new ArrayList<>();
		
		Date from = fromParam.getDate();
		Date to = toParam.getDate();
		
		if (from.compareTo(to) >= 0) {
			throw new InvalidDateException("From should be on or before to");
		}
		for (Ticket ticket : bookedTickets.values()) {
			if ((ticket.getJourneyDate().compareTo(from) >= 0) && (ticket.getJourneyDate().compareTo(to) <= 0)) {
				tickets.add(ticket);
			}

		}

		return tickets;
	}

	private static Ticket createTicket() {
		Ticket ticket = new Ticket();
		ticket.setCustomer(createCustomer());
		ticket.setBookingDate(new Date());
		ticket.setJourneyDate(new Date());
		ticket.setSource("Bangalore");
		ticket.setDestination("New Delhi");
		ticket.setCost(5000F);

		return ticket;
	}

	private static Customer createCustomer() {
		Customer customer = new Customer();
		customer.setId(12345L);
		customer.setName("BT");
		customer.setAddress("Bangalore");
		customer.setPhoneNumber("12345678");
		customer.setDob(new Date());
		customer.setGender(Gender.MALE);
		customer.setIdProof(IdProofType.PAN);

		return customer;
	}

}
