package com.bt.webservices.service;

import java.util.List;

import javax.ws.rs.core.Response;

import com.bt.webservices.adapter.DateParameter;
import com.bt.webservices.entity.Ticket;

public interface TicketBookingService {
	String bookTicket(Ticket ticketToBook);

	Ticket getTicket(String id);

	List<Ticket> getTickets(DateParameter fromParam, DateParameter toParam) throws InvalidDateException;

	Response getCustomerDetails(String ticketId);
}
