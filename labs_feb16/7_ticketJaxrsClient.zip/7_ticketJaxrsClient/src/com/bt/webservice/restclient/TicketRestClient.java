package com.bt.webservice.restclient;

import java.util.Date;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.bt.webservices.entity.Customer;
import com.bt.webservices.entity.Gender;
import com.bt.webservices.entity.IdProofType;
import com.bt.webservices.entity.Ticket;
import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;

public class TicketRestClient {

	public static void main(String[] args) {
		Client restClient = ClientBuilder.newClient();

		WebTarget base = restClient.target("http://localhost:8080/6_ticketJaxrsServer/api");
		base.register(JacksonJsonProvider.class);
		
		String ticketId = createTicket(base);
		
		Ticket ticket = getTicket(base, ticketId);
		System.out.println("Got ticket " + ticket.getId());
	}

	private static Ticket getTicket(WebTarget base, String ticketId) {
		WebTarget customerTarget = base.path("tickets").path(ticketId);
		
		Builder builder = customerTarget.request();
		
		Invocation inv = builder.accept(MediaType.APPLICATION_JSON).buildGet();
		
		Ticket ticket = inv.invoke(Ticket.class);
		return ticket;
	}

	private static String createTicket(WebTarget base) {
		WebTarget customerTarget = base.path("tickets");
		
		Builder builder = customerTarget.request();
		Invocation invocation = builder.accept(MediaType.APPLICATION_XML)
				.buildPost(Entity.entity(createTicket(), MediaType.APPLICATION_XML));

		Response response = invocation.invoke();

		String ticketId = response.readEntity(String.class);
		System.out.println(ticketId);

		return ticketId;
	}

	private static Ticket createTicket() {
		Ticket ticket = new Ticket();
		ticket.setCustomer(createCustomer());
		ticket.setBookingDate(new Date());
		ticket.setJourneyDate(new Date());
		ticket.setSource("Kashmir");
		ticket.setDestination("New Delhi");
		ticket.setCost(5000F);

		return ticket;
	}

	private static Customer createCustomer() {
		Customer customer = new Customer();
		customer.setId(12345L);
		customer.setName("BT");
		customer.setAddress("Bangalore");
		customer.setPhoneNumber("12345678");
		customer.setDob(new Date());
		customer.setGender(Gender.MALE);
		customer.setIdProof(IdProofType.PAN);

		return customer;
	}

}
