package com.bt.ws.entity;

public enum Status {
	ACTIVE, LOCKED, DISABLED, CLOSED;
}
