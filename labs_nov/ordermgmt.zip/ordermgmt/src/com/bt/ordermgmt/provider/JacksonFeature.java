package com.bt.ordermgmt.provider;

import javax.ws.rs.core.Feature;
import javax.ws.rs.core.FeatureContext;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.MessageBodyWriter;

import org.glassfish.jersey.server.ServerProperties;

import com.fasterxml.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;

public class JacksonFeature implements Feature {
	public boolean configure(FeatureContext context) {
//		String disableMoxy = "jersey.config.disableMoxyJson."
//				+ context.getConfiguration().getRuntimeType().name()
//						.toLowerCase();
		context.property(ServerProperties.MOXY_JSON_FEATURE_DISABLE, (Object) true);
		context.register((Class) JacksonJsonProvider.class, new Class[] {
				MessageBodyReader.class, MessageBodyWriter.class });
		return true;
	}
}