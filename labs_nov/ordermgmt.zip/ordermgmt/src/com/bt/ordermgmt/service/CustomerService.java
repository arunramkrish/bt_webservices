package com.bt.ordermgmt.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

import com.bt.ordermgmt.model.Customer;

@Path("/customers")
public class CustomerService {
	public static Map<Long, Customer> customers = new HashMap<>();
	
	public CustomerService() {
	}
	
	@POST
	@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public Customer createCustomer(Customer cus) {
		cus.setId(customers.size() + 1L);
		
		customers.put(cus.getId(), cus);
		
		return cus;
	}

	@GET
	public Collection<Customer> get() {
		return customers.values();
	}
	
	@GET
	@Path("/{id}")
	public Customer getCustomer(@PathParam("id") Long id) {
		return customers.get(id);
	}

	@PUT
	@Path("/{id}")
	@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public Customer createCustomer(@PathParam("id") Long id, Customer cus) {
		customers.put(id, cus);
		
		return cus;
	}

	@DELETE
	@Path("/{id}")
	public Customer delete(@PathParam("id") Long id) {
		return customers.remove(id);
	}

}
