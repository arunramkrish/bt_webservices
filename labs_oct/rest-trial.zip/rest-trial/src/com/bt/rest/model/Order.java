package com.bt.rest.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Order {
	private Long id;
	private String itemName;
	private Double amount;
	private Customer customer;
	private Date orderDate;
	
	@Override
	public String toString() {
		return "Order [id=" + id + ", itemName=" + itemName + ", amount="
				+ amount + ", customer=" + customer + ", orderDate="
				+ orderDate + "]";
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Order(Long id, String itemName, Double amount, Customer customer,
			Date orderDate) {
		super();
		this.id = id;
		this.itemName = itemName;
		this.amount = amount;
		this.customer = customer;
		this.orderDate = orderDate;
	}
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
}
