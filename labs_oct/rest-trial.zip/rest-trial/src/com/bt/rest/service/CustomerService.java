package com.bt.rest.service;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.bt.rest.model.Customer;

@Path("/customers")
public class CustomerService {
	private static Map<Long, Customer> customers = 
			new HashMap<Long, Customer>();
	
	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public Customer create(Customer customer) {
		int cusCount = customers.size();
		
		customer.setId(cusCount + 1L);
		
		customers.put(cusCount + 1L, customer);
		
		return customer;
	}
	
	@Path("/{id}")
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public Customer get(@PathParam("id") Long id) {
		if (customers.containsKey(id)) {
			return customers.get(id);
		} else {
			return new Customer(1L, "dummy", "dummy");
		}
	}
	
}
